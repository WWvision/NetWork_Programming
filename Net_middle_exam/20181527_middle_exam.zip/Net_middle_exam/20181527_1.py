str = 'Hello, IoT'

#1
print(str*3)
#2
print(str[:4])
#3
print(str[-4:])
#4
question4 = str.lower()
print(question4)
#5
print(str[::-1])